# Dashboard SBML — Cloudflare Worker TANPA folder public

Versi ini sengaja **tidak menggunakan** `assets.directory`. Dashboard HTML sudah dibundel ke dalam `worker.js`, termasuk diagram pie Disetujui/Ditolak, matriks 9 kolom, pencarian, filter, ekspor dan mode data lokal.

## Cara deploy via GitHub + Cloudflare

1. Ekstrak ZIP ini di komputer. **Jangan unggah file ZIP saja ke GitHub**.
2. Di repository GitHub yang terhubung ke Cloudflare, hapus atau ganti konfigurasi `wrangler.jsonc` lama yang memiliki `"assets"` / `"directory": "./public"`.
3. Unggah **semua file hasil ekstrak ke tingkat paling atas (root) repository**:
   - `worker.js`
   - `wrangler.jsonc`
   - `package.json`
   - `README.md`
   - `template-sbml.csv`
4. Pastikan GitHub menampilkan file `worker.js` dan `wrangler.jsonc` di root **pada branch yang digunakan Cloudflare** (seringnya `main`). Commit perubahan.
5. Cloudflare -> Workers & Pages -> pilih Worker -> Settings/Build -> cek Git repository, branch, Root directory (root repository) dan Deploy command `npx wrangler deploy`. Build command boleh kosong.
6. Jalankan **Retry deploy** setelah commit dan lihat log terbaru.
7. Dashboard tersedia di `https://<nama-worker>.<subdomain>.workers.dev/`. Saat pertama kali dibuka, data contoh akan tampil.

### Bila masih muncul error `assets.directory ... /public`:

Cloudflare **masih membaca konfigurasi lama**, sebab file `wrangler.jsonc` di paket ini tidak memiliki properti `assets` sama sekali. Periksa repository/branch yang dipakai dan apakah ada file `wrangler.toml`/`wrangler.json` lain yang diprioritaskan atau konfigurasi khusus di Cloudflare. Pastikan commit penggantian `wrangler.jsonc` sudah masuk ke branch deploy; lihat commit hash yang muncul pada build log. Periksa apakah Root directory mengarah ke folder lain.

## Pengujian lokal (opsional)

```bash
npm install
npx wrangler dev
```
Buka `http://localhost:8787/`.

## Google Sheets baca-saja (opsional)

Buat Sheet dengan tab `SBML` dan header baris pertama persis seperti:

`No,Nama KL,Tahun,No Surat / Tgl,Perihal,Surat Menkeu / Tgl,Karakteristik K/L,Jenis SBML,Status`

Aktifkan Google Sheets API di Google Cloud, buat Service Account, bagikan spreadsheet ke email Service Account sebagai Viewer. Atur Worker **secrets** `SHEET_ID`, `GOOGLE_CLIENT_EMAIL`, `GOOGLE_PRIVATE_KEY` melalui Cloudflare Settings / Variables and Secrets. Jangan menuliskan private key di GitHub. Jalur `/api/sbml` membaca Sheet dan tidak menulisnya. Tanpa secrets, dashboard otomatis beralih ke data lokal/contoh.

**Keamanan**: aplikasi dan endpoint API ini tidak memiliki autentikasi. Untuk surat/dokumen internal gunakan Cloudflare Access atau mekanisme akses terotorisasi sebelum menyimpan data sensitif.

## Arti status untuk pie

Grafik hanya membandingkan keputusan `Disetujui` dan `Ditolak`; status lain tetap dihitung pada kartu ringkasan tetapi tidak masuk persentase pie. Data awal hanya contoh.
